# -*- coding: utf-8 -*-
"""
Created on Thu Sep 23 09:17:16 2021

@author: rober
"""

import random

count = 1
max = 6
compguess = random.randint(1, 100)
playerguess = int(input('Pick a number between 1 and 100. '))
while count <= max:
    if compguess == playerguess:
        print('Correct! You win! I guessed', compguess, '.')
        break
    elif compguess > playerguess:
        print('Higher. You have', max-count, 'tries remaining.')
    elif compguess < playerguess:
        print('Lower. You have', max-count, 'tries remaining.')
    if count < max:          
        playerguess = int(input('Pick a number between 1 and 100. '))
    count = count + 1
else:
    print('You reached the maximum number of tries. Computer wins! The number was', compguess)