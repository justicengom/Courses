# -*- coding: utf-8 -*-
"""
Created on Fri Sep 17 15:21:47 2021

@author: rober
"""

import random
import pandas as pd

#global variable definitions
playgame = 1

#RPSLS global variable definitions
RPSLSdict = {1:'rock', 2:'paper', 3:'scissors', 4:'lizard', 5:'Spock'}
RPSLSrulesdict = {1:{2:'covers',5:'vaporizes'}, 2:{3:'cuts',4:'eats'}, 3:{1:'crushes',5:'smashes'}, 4:{1:'crushes',3:'decapitates'}, 5:{2:'disproves',4:'poisons'}}

#function for rock-paper-scissors-lizard-spock
def RPSLS():    
    compguess = random.randint(1, 5)
    compguessname = RPSLSdict[compguess]
    playerguess = int(input('What is your guess? Select 1 for rock, 2 for paper, 3 for scissors, 4 for lizard, and 5 for Spock. '))
    playerguessname = RPSLSdict[playerguess]
    if compguess == playerguess:
        print('Tie! I guessed', compguessname, 'and you guessed', playerguessname)
    else:
        RPSLSrulestemp = RPSLSrulesdict[playerguess]
        if compguess in RPSLSrulestemp:        
            RPSLSactionword = RPSLSrulestemp[compguess]
            print('I guessed', compguessname) 
            print('You lose because', compguessname, RPSLSactionword, playerguessname)
        else:
            RPSLSrulestemp = RPSLSrulesdict[compguess]
            RPSLSactionword = RPSLSrulestemp[playerguess]
            print('I guessed', compguessname)
            print('You win because', playerguessname, RPSLSactionword, compguessname)

def NumGuess():
    count = 1
    max = 6
    compguess = random.randint(1, 100)
    playerguess = int(input('Pick a number between 1 and 100. '))
    while count <= max:
        if compguess == playerguess:
            print('Correct! You win! I guessed', compguess, '.')
            break
        elif compguess > playerguess:
            print('Higher. You have', max-count, 'tries remaining.')
        elif compguess < playerguess:
            print('Lower. You have', max-count, 'tries remaining.')
        if count < max:          
            playerguess = int(input('Pick a number between 1 and 100. '))
        count = count + 1
    else:
        print('You reached the maximum number of tries. Computer wins! The number was', compguess)

def QuizGame():
    # Open Excel file FamilyFeudQuestionDB.xlsx and read sheet labeled 3 Answers
    df = open('R:\ICER\ICERtraining\Python\ICERmod4\FamilyFeudQuestionDB.txt')
    df.readline()

    print()
    print('According to survey results, pick the answer that got the most votes.')
    print()

    #select question randomly
    questionnum = random.randint(1, 1049)
    x = 1
    while x < questionnum:
        quizrow = df.readline()
        x = 1 + x
    question = quizrow.split("\t")
    correctanswer = question[1]
    answerlist = [question[1], question[3], question[5], question[7], question[9]]
    random.shuffle(answerlist)
              
    print(question[0])
    print("1 ", answerlist[0])
    print("2 ", answerlist[1])
    print("3 ", answerlist[2])
    print("4 ", answerlist[3])
    print("5 ", answerlist[4])
    answernum = int(input("Select your answer: "))
    answer = answerlist[answernum-1]
    questionposition = (question.index(answer)+1)
    percentage = question[questionposition]

    print()
    print(answer,"was the answer you selected.")
    print("Coming in at", percentage, "%.") 
    if correctanswer == answer:
        print("You are correct!")
    else:
        print("You are incorrect.")
    print("The correct answer is", correctanswer, "with a", question[2], "%.")


#main program
print('Welcome!')
while playgame == 1:
    gametype = int(input('Press 1 to play rock-paper-scissors-lizard-Spock game, 2 for the number guess game, or 3 for the quiz game. '))
    if gametype == 1:
        RPSLS()
    elif gametype == 2:
        NumGuess()
    elif gametype == 3:
        QuizGame()
    else:
        print('Please select again.')
        #gametype = int(input('Press 1 to play rock-paper-scissors-lizard-spock or 2 for the number guess game. '))  
    playgame = int(input('Do you want to play another game? Press 1 to play a game. '))
    if playgame != 1:
        print('Goodbye!')
        break