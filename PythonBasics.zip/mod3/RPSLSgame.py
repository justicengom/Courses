# -*- coding: utf-8 -*-
"""
Created on Tue Sep 28 10:26:22 2021

@author: rober
"""

import random

RPSLSdict = {1:'rock', 2:'paper', 3:'scissors', 4:'lizard', 5:'Spock'}
RPSLSrulesdict = {1:{2:'covers',5:'vaporizes'}, 2:{3:'cuts',4:'eats'}, 3:{1:'crushes',5:'smashes'}, 4:{1:'crushes',3:'decapitates'}, 5:{2:'disproves',4:'poisons'}}

compguess = random.randint(1, 5)
compguessname = RPSLSdict[compguess]
playerguess = int(input('What is your guess? Select 1 for rock, 2 for paper, 3 for scissors, 4 for lizard, and 5 for Spock. '))
playerguessname = RPSLSdict[playerguess]
if compguess == playerguess:
    print('Tie! I guessed', compguessname, 'and you guessed', playerguessname)
else:
    RPSLSrulestemp = RPSLSrulesdict[playerguess]
    if compguess in RPSLSrulestemp:        
        RPSLSactionword = RPSLSrulestemp[compguess]
        print('I guessed', compguessname) 
        print('You lose because', compguessname, RPSLSactionword, playerguessname)
    else:
        RPSLSrulestemp = RPSLSrulesdict[compguess]
        print(type(RPSLSrulestemp))
        RPSLSactionword = RPSLSrulestemp[playerguess]
        print('I guessed', compguessname)
        print('You win because', playerguessname, RPSLSactionword, compguessname)