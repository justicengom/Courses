import random

# Open Excel file FamilyFeudQuestionDB.xlsx and read sheet labeled 3 Answers
df = open('R:\ICER\ICERtraining\Python\ICERmod4\FamilyFeudQuestionDB.txt')
df.readline()

print()
print('According to survey results, pick the answer that got the most votes.')
print()

#select question randomly
questionnum = random.randint(1, 1049)
x = 1
while x < questionnum:
    quizrow = df.readline()
    x = 1 + x
question = quizrow.split("\t")
correctanswer = question[1]
answerlist = [question[1], question[3], question[5], question[7], question[9]]
random.shuffle(answerlist)
              
print(question[0])
print("1 ", answerlist[0])
print("2 ", answerlist[1])
print("3 ", answerlist[2])
print("4 ", answerlist[3])
print("5 ", answerlist[4])
answernum = int(input("Select your answer: "))
answer = answerlist[answernum-1]
questionposition = (question.index(answer)+1)
percentage = question[questionposition]

print()
print(answer,"was the answer you selected.")
print("Coming in at", percentage, "%.") 
if correctanswer == answer:
    print("You are correct!")
else:
    print("You are incorrect.")
print("The correct answer is", correctanswer, "with a", question[2], "%.")